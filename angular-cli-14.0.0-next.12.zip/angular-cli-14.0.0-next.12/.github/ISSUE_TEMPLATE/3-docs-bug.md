---
name: '📚 Docs or angular.io issue report'
about: Report an issue in Angular's documentation or angular.io application
---

🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑

Please file any Docs or angular.io issues at: https://github.com/angular/angular/issues/new/choose

For the time being, we keep Angular AIO issues in a separate repository.

🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑
